const fileInput = document.getElementById('fileInput');
document.getElementById('uploadBtn').addEventListener('click', () => {
  fileInput.click();
});
fileInput.addEventListener('change', () => {
  const file = fileInput.files && fileInput.files[0];
  if (file) alert(`Selected: ${file.name}\nDemo only — upload storage/backend is not connected yet.`);
});
document.getElementById('loginBtn').addEventListener('click', () => {
  alert('Login UI is a placeholder. Secure email/phone authentication must be connected before launch.');
});
document.querySelectorAll('.like').forEach(button => {
  button.addEventListener('click', () => {
    button.classList.toggle('liked');
    button.firstChild.textContent = button.classList.contains('liked') ? '♥ ' : '♡ ';
  });
});
document.querySelectorAll('.comment,.share').forEach(button => {
  button.addEventListener('click', () => alert('This demo button is not connected to a backend yet.'));
});
document.getElementById('searchInput').addEventListener('keydown', event => {
  if (event.key === 'Enter') alert('Search will work after the video and user database is connected.');
});
